function shopping()
{
	console.log("go to shopping center");
	console.log("buy a product");
	console.log("go back home");
}

shopping();
